<?php

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/../middleware/AuthMiddleware.php';

class AuthController {
    private $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    public function register() {
        $input = json_decode(file_get_contents('php://input'), true);

        if (empty($input['name']) || empty($input['email']) || empty($input['password'])) {
            Response::error('Name, email and password are required', 400);
        }

        if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
            Response::error('Invalid email format', 400);
        }

        if (strlen($input['password']) < 6) {
            Response::error('Password must be at least 6 characters', 400);
        }

        if ($this->userModel->findByEmail($input['email'])) {
            Response::error('Email already exists', 409);
        }

        $userId = $this->userModel->create(
            $input['name'],
            $input['email'],
            $input['password']
        );

        $token = $this->generateToken($userId);

        Response::success([
            'user' => [
                'id' => (int)$userId,
                'name' => $input['name'],
                'email' => $input['email']
            ],
            'token' => $token
        ], 'Registration successful', 201);
    }

    public function login() {
        $input = json_decode(file_get_contents('php://input'), true);

        if (empty($input['email']) || empty($input['password'])) {
            Response::error('Email and password are required', 400);
        }

        $user = $this->userModel->findByEmail($input['email']);

        if (!$user || !password_verify($input['password'], $user['password'])) {
            Response::error('Invalid credentials', 401);
        }

        $token = $this->generateToken($user['id']);

        Response::success([
            'user' => [
                'id' => (int)$user['id'],
                'name' => $user['name'],
                'email' => $user['email']
            ],
            'token' => $token
        ], 'Login successful');
    }

    public function me() {
        $user = AuthMiddleware::authenticate();
        $userData = $this->userModel->findById($user['id']);
        Response::success($userData);
    }

    public function logout() {
        $user = AuthMiddleware::authenticate();
        $headers = getallheaders();
        $token = substr($headers['Authorization'], 7);

        $db = (new Database())->getConnection();
        $stmt = $db->prepare("DELETE FROM auth_tokens WHERE token = :token");
        $stmt->execute([':token' => $token]);

        Response::success(null, 'Logout successful');
    }

    private function generateToken($userId) {
        $db = (new Database())->getConnection();
        $token = bin2hex(openssl_random_pseudo_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', strtotime('+7 days'));

        $stmt = $db->prepare(
            "INSERT INTO auth_tokens (user_id, token, expires_at) VALUES (:user_id, :token, :expires_at)"
        );
        $stmt->execute([
            ':user_id' => $userId,
            ':token' => $token,
            ':expires_at' => $expiresAt
        ]);

        return $token;
    }
}
